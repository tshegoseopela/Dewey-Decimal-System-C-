﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ST10122250_PROG_Pt1
{
    /// <summary>
    /// Interaction logic for IdentifyAreas.xaml
    /// </summary>
    public partial class IdentifyAreas : Window
    {

        public IdentifyAreas()
        {
            InitializeComponent();
            //hidding the label, listbox and button related to the correct answer
            btnAnswer.Visibility = Visibility.Hidden;
            lblAnswer.Visibility = Visibility.Hidden;
            lstAnswer.Visibility = Visibility.Hidden;
            pgGamification.Visibility = Visibility.Hidden;
            imgLoser.Visibility = Visibility.Hidden;
            imgWin.Visibility = Visibility.Hidden;
        }

        Dictionary<string,string> objDS = new Dictionary<string, string>(); //pre-defined dictionary
        Dictionary<string,string> userDic = new Dictionary<string, string>(); //user generated dictionary
        Random methRan1 = new Random();
        public static int methRan;

        private void btnGenerate_Click(object sender, RoutedEventArgs e)
        {
            methRan = methRan1.Next(6);
            if (methRan <=3)
            {
                //Odd click job
            keysFirst();
        }
            else if(methRan <=6)
            {
                // Even click job
                valuesFirst();
            }

        }

        /// <summary>
        /// This method generates the call numbers on the left and the descriptions on the right
        /// </summary>
        private void keysFirst()
        {
            //clearing the components
            lstKey.Items.Clear();
            lstValue.Items.Clear();
            objDS.Clear();

            //populating the dictionary with call numbers and descriptions
            objDS.Add("000", "General Knowledge");
            objDS.Add("100", "Philosophy and Psychology");
            objDS.Add("200", "Religion");
            objDS.Add("300", "Social Sciences");
            objDS.Add("400", "Languages");
            objDS.Add("500", "Science");
            objDS.Add("600", "Technology");
            objDS.Add("700", "Arts and Recreation");
            objDS.Add("800", "Literature");
            objDS.Add("900", "History and Geography");

            Random rand = new Random();

            //randomly selecting 4 keys and values from the dictionary
            List<int> callTemp = new List<int>();
            List<string> desTemp = new List<string>();

            //getting the keys
            while (callTemp.Count < 4)
            {
                int x = rand.Next(objDS.Count - 1);
                //populating the listbox with the keys (call number)
                if (!callTemp.Contains(x))
                {
                    lstKey.Items.Add(objDS.ElementAt(x).Key);
                    callTemp.Add(x);

                    if (callTemp.Contains(x))
                    {
                        desTemp.Add(String.Join(" ", objDS.ElementAt(x).Value));
                    }
                }
            }

            //getting the description
            while (callTemp.Count < 7)
            {
                int y = rand.Next(objDS.Count - 1);
                //populating the listbox with the values (descriptions)
                if (!callTemp.Contains(y))
                {
                    //lstValue.Items.Add(objDS.ElementAt(y).Value);
                    callTemp.Add(y);
                    if (callTemp.Contains(y))
                    {
                        desTemp.Add(String.Join(" ", objDS.ElementAt(y).Value));
                    }
                }
            }

            var rnd = new Random();
            var randomise = desTemp.OrderBy(item => rnd.Next());
            foreach (string item in randomise)
            {
                lstValue.Items.Add(item);
            }
        }

        /// <summary>
        /// This method generates the descriptions on the left and the call numbers on the right
        /// </summary>
        private void valuesFirst()
        {
            //clearing the components
            lstKey.Items.Clear();
            lstValue.Items.Clear();
            objDS.Clear();

            //populating the dictionary with call numbers and descriptions
            objDS.Add("000", "General Knowledge");
            objDS.Add("100", "Philosophy and Psychology");
            objDS.Add("200", "Religion");
            objDS.Add("300", "Social Sciences");
            objDS.Add("400", "Languages");
            objDS.Add("500", "Science");
            objDS.Add("600", "Technology");
            objDS.Add("700", "Arts and Recreation");
            objDS.Add("800", "Literature");
            objDS.Add("900", "History and Geography");

            Random rand = new Random();

            //randomly selecting 4 keys and values from the dictionary
            List<int> callTemp = new List<int>();
            List<string> desTemp = new List<string>();

            //getting the keys
            while (callTemp.Count < 4)
            {
                int x = rand.Next(objDS.Count - 1);
                //populating the listbox with the keys (call number)
                if (!callTemp.Contains(x))
                {
                    lstKey.Items.Add(objDS.ElementAt(x).Value);
                    callTemp.Add(x);

                    if (callTemp.Contains(x))
                    {
                        desTemp.Add(String.Join(" ", objDS.ElementAt(x).Key));
                    }
                }
            }

            //getting the description
            while (callTemp.Count < 7)
            {
                int y = rand.Next(objDS.Count - 1);
                //populating the listbox with the values (descriptions)
                if (!callTemp.Contains(y))
                {
                    //lstValue.Items.Add(objDS.ElementAt(y).Value);
                    callTemp.Add(y);
                    if (callTemp.Contains(y))
                    {
                        desTemp.Add(String.Join(" ", objDS.ElementAt(y).Key));
                    }
                }
            }

            var rnd = new Random();
            var randomise = desTemp.OrderBy(item => rnd.Next());
            foreach (string item in randomise)
            {
                lstValue.Items.Add(item);
            }
        }

        /// <summary>
        /// This method moves the call numbers first then the descriptions after
        /// </summary>
        private void moveKeys()
        {
            lstUser.Items.Add($"{lstKey.SelectedItem}-{lstValue.SelectedItem}");
            lstKey.Items.Remove(lstKey.SelectedItem); //removing the selected items from one of the listboxes
            lstValue.Items.Remove(lstValue.SelectedItem); //removing the selected items from one of the listboxes
            //lstKey.Items.Remove(lstKey.SelectedItem);
        }

        /// <summary>
        /// This method moves the descriptions first then the call numbers after
        /// </summary>
        private void moveValues()
        {
            lstUser.Items.Add($"{lstValue.SelectedItem}-{lstKey.SelectedItem}");
            lstKey.Items.Remove(lstKey.SelectedItem); //removing the selected items from one of the listboxes
            lstValue.Items.Remove(lstValue.SelectedItem); //removing the selected items from one of the listboxes
            //lstKey.Items.Remove(lstKey.SelectedItem);
        }

        /// <summary>
        /// This button will enable the user to answer as many questions as they want
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnRetry_Click(object sender, RoutedEventArgs e)
        {
            //clearing the components
            lstKey.Items.Clear();
            lstValue.Items.Clear();
            lstAnswer.Items.Clear();
            lstUser.Items.Clear();
            btnAnswer.Visibility = Visibility.Hidden;
            pgGamification.Visibility = Visibility.Hidden;
            lblCPoints.Visibility = Visibility.Hidden;
            lblPoints.Visibility = Visibility.Hidden;
            objDS.Clear();
            userDic.Clear();
            imgLoser.Visibility = Visibility.Hidden;
            imgWin.Visibility = Visibility.Hidden;
        }

        /// <summary>
        /// This button will take the selected items in the listboxes
        /// and pair them as one instance of a object. (Transfer to new Listbox)
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnTransfer_Click(object sender, RoutedEventArgs e)
        {
            if (methRan <= 3)
            {
                moveKeys();
            }else if(methRan <= 6){
                moveValues();
            }

            if (lstUser.Items.Count == 4)
            {
                lstAnswer.Visibility = Visibility.Visible;
                btnAnswer.Visibility = Visibility.Visible;
                lblAnswer.Visibility = Visibility.Visible;
            }
        }

        /// <summary>
        /// This button will allow the user to put back an object 
        /// they mistakenly added
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnPutback_Click(object sender, RoutedEventArgs e)
        {
            //converting each object in the listbox into string
            string split = lstUser.SelectedItem.ToString();
            var spl = split.Split('-'); //using - as a delimeter
            lstKey.Items.Add(spl[0]); //adding strings before delimeter back into key listbox
            lstValue.Items.Add(spl[1]); //adding strings after delimeter back into value listbox
            lstUser.Items.Remove(lstUser.SelectedItem); //removing the selected items from the user listbox
        }

        /// <summary>
        /// Coompare the user generated dictionary and the pre-defined dictionary
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnAnswer_Click(object sender, RoutedEventArgs e)
        {
            //converting the items from the listbox into string and adding them into the user generated dictionary
            for (int i = 0; i < lstUser.Items.Count; i++)
            {
                string item = lstUser.Items[i].ToString(); //converting each object into string
                int index = item.IndexOf("-"); //using - as a delimeter
                //taking all the string characters before the delimeter and saving in this variable
                string cn = Convert.ToString(item.Substring(0, index));
                string tp = item.Substring(index + 1); //taking all the characters after the delimeter and storing it into this variable

                userDic.Add(cn, tp); //populating the new dictionary to compare with the already instantiated dictionary
            }

            pgGamification.Visibility = Visibility.Visible;

            int count = 0;
            //count2 = 0;
            //comparing the user generated dictionary and the pre-defined dictionary
            foreach (KeyValuePair<string, string> pair in userDic)
            {
                if (objDS.TryGetValue(pair.Key, out string val) && (val.Equals(pair.Value)))
                {
                    count++;
                    lstAnswer.Items.Add($"{pair.Key}-{val}");
                    imgWin.Visibility = Visibility.Visible;
                }
                else
                {
                    MessageBox.Show("You didn't get them all correct");
                    lstAnswer.Items.Add($"{pair.Key}-{val}");
                    imgWin.Visibility = Visibility.Hidden;
                    imgLoser.Visibility = Visibility.Visible;
                }
            }

            //displaying the correct number of objects in their order as points
            lblPoints.Visibility = Visibility.Visible;
            lblCPoints.Visibility = Visibility.Visible;
            lblPoints.Content = "Points: " + count * 10;
            pgGamification.Value = count * 25;
            double percentage = (count / 4) * 100;
            lblCPoints.Content = $"This means you got {count} correct out of 4. {percentage}%";
        }
    }
}
