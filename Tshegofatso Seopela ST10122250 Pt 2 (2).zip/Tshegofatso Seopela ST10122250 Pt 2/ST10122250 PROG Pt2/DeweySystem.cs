﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ST10122250_PROG_Pt1
{
    public class DeweySystems : IComparable<DeweySystems>, IEqualityComparer<DeweySystems>
    {
        //attributes of the class and of each book 
        public double callNumbers { get; set; }
        public string authors { get; set; }
        //public string description { get; set; }

        //overloaded constructor
        public DeweySystems(double callNumbers, string authors)
        {
            this.callNumbers = callNumbers;
            this.authors = authors;
            
        }

        //public DeweySystems(double callNumbers, string description)
        //{
        //    this.callNumbers = callNumbers;
        //    this.description = description;
        //}

        //constructor
        public DeweySystems()
        {

        }

        public int CompareTo(DeweySystems ds)
        {
            //can only get 3 values (-1,1,0)
            int result = this.callNumbers.CompareTo(ds.callNumbers);
            if (result == 0)
            {
                result = this.authors.CompareTo(ds.authors);
            }
            return result;
        }

        //populate the listbox in a certain manner (call number - authors)
        public override string? ToString()
        {
            return $"{callNumbers}-{authors}";
        }



        //checking if BOTH objects (callnumbers and authors) are equal to each other 
        public bool Equals(DeweySystems a, DeweySystems b)
        {
            if (a.callNumbers.Equals(b.callNumbers) && a.authors.Equals(b.authors))
            {
                return true;
            }
            return false;
        }


        //compare to lists of a specific type
        public int GetHashCode(DeweySystems obj)
        {
            return obj.GetHashCode();
        }

    }

    /*
     REFERENCES:
    (1) https://stackoverflow.com/questions/257005/how-do-you-round-a-number-to-two-decimal-places-in-c
        Round of two decimal places | Stack Overflow

    (2) https://www.youtube.com/watch?v=AIJM7slUhzg&t=239s&ab_channel=C%23DesignPro
        WPF - Rounded Button - XAML C# Tutorial | YouTube
     */
}
