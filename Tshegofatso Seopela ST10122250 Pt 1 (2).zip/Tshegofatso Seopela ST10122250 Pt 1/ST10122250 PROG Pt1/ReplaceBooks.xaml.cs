﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


namespace ST10122250_PROG_Pt1
{
    /// <summary>
    /// Interaction logic for ReplaceBooks.xaml
    /// </summary>
    public partial class ReplaceBooks : Window
    {
        public ReplaceBooks()
        {
            InitializeComponent();
            imgGamification.Visibility = Visibility.Hidden;
            imgLoser.Visibility = Visibility.Hidden;
        }

        //creating a List of type DeweySystem (list of a specific class)
        List<DeweySystem> objDS = new List<DeweySystem>();
        List<DeweySystem> userList = new List<DeweySystem>();
        int points, count = 0;

        //this button will generate the call numbers + authors randomly randomly
        private void btnGenerate_Click(object sender, RoutedEventArgs e)
        {
            objDS.Clear(); //clearing the list
            userList.Clear();//clearing user list
            lstBox.Items.Clear(); //clearing the list box
            lstDDS.Items.Clear(); //clearing the 2nd list box
            lblPoints.Content = "Points: "; //clearing the points label
            pgbGamification.Value = 0; // clearing the progress bar
            lblgamification.Content = $"Current points: {points}";
            imgGamification.Visibility = Visibility.Hidden; //hiding the images
            imgLoser.Visibility = Visibility.Hidden; //hiding the images

            // instantiating an array of the 10 author names
            string[] authors = new string[] {"King" , "Hemingway" , "Tolstoy" , "Lewis" ,
                                              "Shakespeare" , "Fleming" , "Rowling" ,
                                              "Noland", "Pushkin" , "Seuss"};

            //randomly generating numbers with random selection of author names
            Random random = new Random();

            //looping through 10 times for each author 
            for (int i = 0; i < authors.Length; i++) 
            {
                //generating random call numbers for corresponding authors
                //(1) references- rounding off 2 decimal places
                objDS.Add(new DeweySystem(Math.Round((random.NextDouble() * 10),2), 
                   authors[random.Next(authors.Length - 1)].Substring(0,3).ToUpper()));
            }

            foreach(var x in objDS)
            {
                lstBox.Items.Add(x.ToString());  //displaying this in the list box
            }
        }

        //this button will verify the order and that will be used to compare the user's and the generated lists
        private void btnVerify_Click(object sender, RoutedEventArgs e)
        {
            //bubble sort + populate first ListBox
            sortNums(objDS);

            pgbGamification.Visibility = Visibility.Visible; //making the progress bar visible

            for (int i = 0; i < lstDDS.Items.Count; i++)
            {
                //adding all the elements in the listbox as objects to the user list
                string item = lstDDS.Items[i].ToString(); 
                int index = item.IndexOf("-"); //searching for the dash as a index
                double num = Convert.ToDouble(item.Substring(0, index));
                string name = item.Substring(index + 1);

                userList.Add(new DeweySystem(num, name)); //populating user list
            }

            //checking the user's list and the sorted generated list
            if (objDS.SequenceEqual(userList, new DeweySystem()))
            {
                //if the user gets the entire order correct//
                MessageBox.Show("Correct! You get 10 points");
                Console.Beep(5000, 1000); //advanced feature - gamification
                imgGamification.Visibility = Visibility.Visible; 
            }
            else{
                //if the user gets the order incorrect//
                MessageBox.Show("Incorrect order :(");
                Console.Beep(5000, 500); //advanced feature - gamification
                imgLoser.Visibility = Visibility.Visible;
            }

            //count the number of correct values the user gets
            if (objDS.Count == userList.Count)
            {
                for (int i = 0; i < objDS.Count; i++)
                {
                    if (objDS[i].CompareTo(userList[i]) == 0)
                    {
                        count++;
                    }
                }
            }

            //displaying the correct number of objects in their order as points
            lblPoints.Content = "Points: " + count;
            pgbGamification.Value = count * 10;
            double percentage = (count / 10) * 100;
            lblgamification.Content = $"This means you got {count} correct out of 10. {percentage}%";

        }

        //bubble sort method 
        private void sortNums(List<DeweySystem> ds)
        {
            for(int i = 0; i < ds.Count - 1; i++) // -1 to not go out of bounds of List
            {
                //position of element i + 1 to compare the next element in that position
                for (int j = (i+1); j < ds.Count; j++) 
                {
                    if(ds[i].callNumbers > ds[j].callNumbers) //performing the swap if call number on the left is > call number on the right
                    {
                        DeweySystem temp = ds[i];  //performing swap with temp variable of type DeweySystem (class)
                        ds[i] = ds[j];
                        ds[j] = temp;
                    }

                    if (ds[i].callNumbers == ds[j].callNumbers) //if call numbers are equal compare author surnames
                    {
                        if (ds[i].authors.CompareTo(ds[j].authors) == 1) //sorting the surnames in alphabetical order
                        {
                            DeweySystem temp = ds[i]; //performing swap with temp variable of type DeweySystem (class)
                            ds[i] = ds[j];
                            ds[j] = temp;
                        }
                    }
                }
            }

            foreach(DeweySystem d in ds)
            {
                lstBox.Items.Add(d.ToString()); //populating the listbox with the sorted data
            }
        }

        //button that will allow the user to add the selected item to the new list box (lstDSS)
        private void btnTransfer_Click(object sender, RoutedEventArgs e)
        {
            lstDDS.Items.Add(lstBox.SelectedItem); //transfering the selected item into the next listbox
            lstBox.Items.Remove(lstBox.SelectedItem); //removing the selected items from one of the listboxes
        }

        //button that will allow the user to back track if they add a incorrect object (call number + author)
        private void btnRestart_Click(object sender, RoutedEventArgs e)
        {
            lstBox.Items.Add(lstDDS.SelectedItem); //transfering the selected item into the next listbox
            lstDDS.Items.Remove(lstDDS.SelectedItem); //removing the selected items from one of the listboxes
        }
    }

    class DeweySystem : IComparable<DeweySystem> , IEqualityComparer<DeweySystem>
    {
        //attributes of the class and of each book 
        public double callNumbers { get; set; }
        public string authors { get; set; }

        //overloaded constructor
        public DeweySystem(double callNumbers, string authors)
        {
            this.callNumbers = callNumbers;
            this.authors = authors;
        }

        //constructor
        public DeweySystem()
        {

        }

        public int CompareTo(DeweySystem ds)
        {
            //can only get 3 values (-1,1,0)
            int result = this.callNumbers.CompareTo(ds.callNumbers);
            if (result == 0)
            {
                result = this.authors.CompareTo(ds.authors);
            }
            return result;
        }

        //populate the listbox in a certain manner (call number - authors)
        public override string? ToString()
        {
            return $"{callNumbers}-{authors}";
        }

        //checking if BOTH objects (callnumbers and authors) are equal to each other 
        public bool Equals(DeweySystem a, DeweySystem b)
        {
            if(a.callNumbers.Equals(b.callNumbers) && a.authors.Equals(b.authors))
            {
                return true; 
            }
            return false;
        }

        //compare to lists of a specific type
        public int GetHashCode(DeweySystem obj)
        {
            return obj.GetHashCode();
        }

    }

    /*
     REFERENCES:
    (1) https://stackoverflow.com/questions/257005/how-do-you-round-a-number-to-two-decimal-places-in-c
        Round of two decimal places | Stack Overflow

    (2) https://www.youtube.com/watch?v=AIJM7slUhzg&t=239s&ab_channel=C%23DesignPro
        WPF - Rounded Button - XAML C# Tutorial | YouTube
     */
}
